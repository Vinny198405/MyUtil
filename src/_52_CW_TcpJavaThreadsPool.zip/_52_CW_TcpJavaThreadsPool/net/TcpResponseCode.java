package _52_CW_TcpJavaThreadsPool.net;

public enum TcpResponseCode {
    OK, WRONG_REQUEST,UNKNOWN
}
